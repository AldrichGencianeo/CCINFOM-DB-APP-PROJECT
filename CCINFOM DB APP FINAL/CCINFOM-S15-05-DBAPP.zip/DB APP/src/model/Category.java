package model;

public enum Category {
    Clothing, Collectible, Music, Accessory
}
